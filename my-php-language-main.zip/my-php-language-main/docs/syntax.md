# Language Syntax

## Print
print "text"
