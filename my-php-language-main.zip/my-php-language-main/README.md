# My PHP Programming Language

This is a simple programming language interpreter written in PHP.

## Features
- Simple syntax
- Beginner friendly

## Example
print "Hello world"
